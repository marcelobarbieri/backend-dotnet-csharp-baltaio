﻿namespace UtmBuilder.Core.ValueObjects;

public abstract class ValueObject
{
    
}